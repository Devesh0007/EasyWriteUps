<?php include('connect.php');
function showData(){
	global $con;
	$sql="SELECT * FROM `users`";
	$result = mysqli_query($con,$sql);
	if($result==TRUE)
	{
		while($data=mysqli_fetch_assoc($result))
		{
			echo "<tr><td>".$data['uid']."</td><td>".$data['name']."</td><td>".$data['email']."</td><td>".$data['pass']."</td></tr>";
		}
			
	}
}
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
</head>

<body>
<table align="center" width="100%" border="1px">
<?php showData(); ?>	
</table>

</body>
</html>