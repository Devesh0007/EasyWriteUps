<?php
include('connect.php');

$uname= $_POST['name'];
$pass=sha1($_POST['pass']);
$email=$_POST['email'];

$sql="INSERT INTO `users`(`name`, `email`, `pass`) VALUES ('$uname','$email','$pass')";
$result=mysqli_query($con,$sql);
if($result==TRUE)
	echo "data inserted successfully";
else
	echo "insertion failed";
?>
