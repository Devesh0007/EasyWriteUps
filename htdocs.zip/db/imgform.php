<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
</head>

<body>

<form method="post" action="imgform.php" enctype="multipart/form-data">

	<input type="file" name="img"/>
	<input type="submit" name="submit" value="submit">
	
</form>
</body>
</html>
<?php
	if(isset($_POST['submit']))
	{ 
		$con = mysqli_connect('localhost','root','','testDB') or die(mysqli_error());
		$name=$_FILES['img']['name'];
		$nametmp=$_FILES['img']['tmp_name'];
		move_uploaded_file($nametmp,'images/'.$name);
		$sql="INSERT INTO `images`(`name`) VALUES ('$name')";
		$result=mysqli_query($con,$sql);
		if($result==TRUE)
			echo("<h1>image uploaded successfully...</h1>");
		else
			echo("<h1>upload failed</h1>");
	}
?>