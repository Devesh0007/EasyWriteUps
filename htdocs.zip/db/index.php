<!DOCTYPE html>
<html>
<head>
	<title>insert</title>
</head>
<body>
<form action="insert.php" method="post">
	<fieldset>
		<table align="center">
			<tr>
				<td>username&nbsp;:</td><td><input type="text" name="name" required></td>
			</tr>
			<tr>
				<td>email&nbsp;:</td><td><input type="email" name="email" required></td>
			</tr>
			<tr>
				<td>password&nbsp;:</td><td><input type="password" name="pass" required></td>
			</tr>
			<tr><td colspan="2"><input type="submit" name="submit" value="submit"></td></tr>
		</table>
	</fieldset>
	
</form>
</body>
</html>
