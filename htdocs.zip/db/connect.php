<?php
$con = mysqli_connect('localhost','root','','testDB');
if($con)
{
  //echo "connection established";
}else {
  echo "connection not established";
}
 ?>
